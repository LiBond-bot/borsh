<section class="section-wrapper-4 content-inner-1 overflow-hidden bg-parallax" style="background-image:url('<?=get_template_directory_uri()?>/assets/images/patterns/back_02.png'); background-attachment: fixed; background-size: 800px;">
    <div class="container">
        <div class="section-head text-center">
            <h2 class="title wow flipInX" data-wow-delay="0.2s">Хотим дегустацию!</h2>
            <p>Для оценки блюд наш представитель привезет несколько вариантов</p>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="dz-form-card bg-primary" id="formTastingCorp">
                    <div class="dz-form-card__message">
                        <div class="dz-form-card__message-text">
                            <div>Спасибо, что выбрали нас!</div>
                            <div>Наш менеджер свяжется с вами для подтверждения заказа!</div>
                        </div>
                    </div>
                    <form class="dzForm dezPlaceAni">
                        <div class="row">
                            <div class="col-lg-2 col-md-12 d-flex align-items-center">
                                <div class="input-group input-line">
                                    <input name="phone" required type="text" class="form-control" placeholder="+7 (___) ___-__-__">
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-12 d-flex align-items-center">
                                <div class="input-group input-line">
                                    <input name="name" required type="text" class="form-control" placeholder="Контактное лицо">
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 d-flex align-items-center">
                                <div class="input-group input-line">
                                    <input name="countLunch" required type="text" class="form-control" placeholder="Количество обедов">
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 d-flex align-items-center">
                                <div class="input-group input-line">
                                    <input name="adress" required type="text" class="form-control" placeholder="Адрес">
                                </div>
                            </div>
                            <div class="col-lg-2 col-12">
                                <button type="submit" name="submit" value="submit" class="btn btn-md btn-white btn-hover-1"><span>Заказать</span></button>	
                            </div>
                            <div class="col-12">
                                <div class="dz-form-card__warning-message mt-3">Добавьте еще один, и стоимость обеда будет 300 руб.</div>
                                <div class="mt-3 p-0" style="font-size:14px;">
                                    Нажимая кнопку <b>"Заказать"</b>, вы соглашаетесь с <b><a href="/privacy-policy/">Политикой конфиденциальности</a></b>
                                </div>
                            </div>
                            
                        </div>
                    </form>
                    <input type="hidden" name="title" value="Дегустация меню корпоративный">
                    <input type="hidden" name="WhereForm" value="Форма с блока меню">
                    <input type="hidden" name="typeForm" value="corporate">
                </div>
            </div>
        </div>
    </div>
</section>